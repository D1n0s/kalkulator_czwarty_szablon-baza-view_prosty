package com.jsf.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import cars_bd.Rola;

//DAO - Data Access Object for Rola entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class RolaDAO {
	private final static String UNIT_NAME = "jsfcourse-simplePU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	
	
	
	public void create(Rola Rola) {
		em.persist(Rola);
	}

	public Rola merge(Rola Rola) {
		return em.merge(Rola);
	}

	public void remove(Rola Rola) {
		em.remove(em.merge(Rola));
	}

	public Rola find(Object id) {
		return em.find(Rola.class, id);
	}

	public List<Rola> getFullList() {
		List<Rola> list = null;

		Query query = em.createQuery("select p from Rola p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	public List<Rola> getList(Map<String, Object> searchParams) {
		List<Rola> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Rola p ";
		String where = "";


		// search for surname
		String surname = (String) searchParams.get("surname");
		if (surname != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.surname like :surname ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		if (surname != null) {
			query.setParameter("surname", surname+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

}
